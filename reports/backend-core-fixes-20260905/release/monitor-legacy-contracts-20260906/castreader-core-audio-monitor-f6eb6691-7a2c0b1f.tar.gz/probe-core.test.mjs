import assert from 'node:assert/strict';
import test from 'node:test';

import {
  ProbeContractError,
  assertRegionalEndpoint,
  decodedDurationFromFfmpegProgress,
  runContinuityProbe,
  targetForRegion,
} from './probe-core.mjs';

const MP3 = (() => {
  const bytes = Buffer.alloc(192, 0x55);
  bytes[0] = 0xff;
  bytes[1] = 0xfb;
  return bytes.toString('base64');
})();

function sentencePartition(input, terminator = '。') {
  const offset = input.indexOf(terminator);
  if (offset === -1) return { processed: input, unprocessed: '' };
  const cut = offset + terminator.length;
  return { processed: input.slice(0, cut), unprocessed: input.slice(cut) };
}

function responseFor({ input, region, voice, timestamps = [{ word: 'probe', start: 0, end: 0.6 }], partition }) {
  const split = partition || sentencePartition(input);
  return new Response(JSON.stringify({
    audio: MP3,
    audio_format: 'audio/mpeg',
    timestamps,
    voice_code: voice,
    processed_text: split.processed,
    unprocessed_text: split.unprocessed,
  }), {
    status: 200,
    headers: {
      'content-type': 'application/json',
      'x-castreader-gateway': 'vercel-r2',
      'x-castreader-upstream-region': region,
      'x-castreader-upstream-node': `${region}-diagnostic-node`,
      'x-castreader-upstream-source': `${region}-pinned`,
      'x-castreader-upstream-revision': '7',
    },
  });
}

function fakeCnFetch({ mutate, failFirst = false } = {}) {
  const requests = [];
  let calls = 0;
  const fetchImpl = async (url, init) => {
    calls += 1;
    const body = JSON.parse(init.body);
    requests.push({ url, init, body });
    if (failFirst && calls === 1) throw new TypeError('diagnostic network failure');
    const base = {
      input: body.input,
      region: 'cn',
      voice: body.voice_code,
    };
    return responseFor(mutate ? mutate(base, calls) : base);
  };
  return { fetchImpl, requests };
}

const decodeAudio = async (bytes) => {
  assert.equal(bytes[0], 0xff);
  assert.equal(bytes[1], 0xfb);
  return { durationSeconds: 0.75 };
};

test('CN probe follows every remainder and validates multiple decodable segments', async () => {
  const { fetchImpl, requests } = fakeCnFetch();
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, maxAttemptsPerSegment: 1, retryDelayMs: 0,
  });

  assert.equal(outcome.status, 'healthy');
  assert.equal(outcome.supplyOk, true);
  assert.equal(outcome.alignmentOk, true);
  assert.equal(outcome.segmentCount, 3);
  assert.equal(outcome.totalAudioBytes, 3 * 192);
  assert.equal(outcome.totalDurationSeconds, 2.25);
  assert.equal(requests[0].body.input, targetForRegion('cn').input);
  assert.equal(requests.at(-1).body.input, '第三段确认每一段音频都能独立解码并按顺序播放。');
  assert.equal(Object.hasOwn(requests[0].body, 'stream'), false);
  assert.equal(requests[1].body.stream, true);
  assert.equal(requests[2].body.stream, false);
  assert.deepEqual(outcome.segments.map((segment) => segment.requestContract), ['stream_omitted', 'stream_true', 'stream_false']);
  assert.equal(requests.map(({ body }) => body.input.slice(0, body.input.indexOf('。') + 1)).join(''), targetForRegion('cn').input);
  for (const { url, init, body } of requests) {
    assert.equal(url, 'https://api.castreader.cn/api/captioned_speech_partly');
    assert.equal(init.redirect, 'error');
    assert.equal(body.voice_code, 'zf_001');
    assert.equal(body.voice, 'zf_001');
    assert.equal(body.language, 'zh');
  }
  assert.equal('input' in outcome, false);
  assert.equal('audio' in outcome, false);
});

test('US probe uses its global route and follows an exact English remainder', async () => {
  const requests = [];
  const fetchImpl = async (url, init) => {
    const body = JSON.parse(init.body);
    requests.push({ url, init, body });
    return responseFor({
      input: body.input,
      region: 'global',
      voice: body.voice_code,
      partition: sentencePartition(body.input, '.'),
    });
  };
  const outcome = await runContinuityProbe({
    region: 'us', fetchImpl, decodeAudio, maxAttemptsPerSegment: 1, retryDelayMs: 0,
  });
  assert.equal(outcome.status, 'healthy');
  assert.ok(outcome.segmentCount >= 2);
  assert.equal(requests[0].url, 'https://api.castreader.ai/api/captioned_speech_partly');
  assert.equal(requests[0].body.voice_code, 'af_heart');
  assert.equal(requests[0].body.language, 'en');
  assert.equal(requests.map(({ body }) => sentencePartition(body.input, '.').processed).join(''), targetForRegion('us').input);
});

test('timestamp failure degrades alignment without failing playable supply', async () => {
  const { fetchImpl } = fakeCnFetch({
    mutate: (base, calls) => ({ ...base, ...(calls === 2 ? { timestamps: [] } : {}) }),
  });
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, maxAttemptsPerSegment: 1, retryDelayMs: 0,
  });
  assert.equal(outcome.status, 'alignment_degraded');
  assert.equal(outcome.supplyOk, true);
  assert.equal(outcome.alignmentOk, false);
  assert.equal(outcome.segmentCount, 3);
});

test('a changed or lost remainder fails the continuity contract', async () => {
  const { fetchImpl } = fakeCnFetch({
    mutate: (base) => {
      const split = sentencePartition(base.input);
      return { ...base, partition: { processed: split.processed, unprocessed: split.unprocessed.slice(1) } };
    },
  });
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, maxAttemptsPerSegment: 1, retryDelayMs: 0,
  });
  assert.equal(outcome.status, 'supply_failed');
  assert.equal(outcome.failureCode, 'remainder_did_not_advance');
  assert.equal(outcome.segmentCount, 0);
});

test('a one-response success cannot claim continuous multi-segment supply', async () => {
  const target = targetForRegion('cn');
  const fetchImpl = async () => new Response(JSON.stringify({
    audio: MP3,
    timestamps: [{ word: 'probe', start: 0, end: 1 }],
    voice_code: target.voice,
  }), {
    headers: {
      'content-type': 'application/json',
      'x-castreader-upstream-region': 'cn',
    },
  });
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, maxAttemptsPerSegment: 1, retryDelayMs: 0,
  });
  assert.equal(outcome.status, 'supply_failed');
  assert.equal(outcome.failureCode, 'single_segment_contract');
  assert.equal(outcome.segmentCount, 1);
});

test('a response claiming the other service region fails supply', async () => {
  const { fetchImpl } = fakeCnFetch({
    mutate: (base) => ({ ...base, region: 'global' }),
  });
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, maxAttemptsPerSegment: 1, retryDelayMs: 0,
  });
  assert.equal(outcome.status, 'supply_failed');
  assert.equal(outcome.failureCode, 'region_contract_mismatch');
  assert.equal(outcome.segmentCount, 0);
});

test('one transient request failure retries the same segment within the fixed budget', async () => {
  const { fetchImpl, requests } = fakeCnFetch({ failFirst: true });
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, maxAttemptsPerSegment: 2, retryDelayMs: 0,
  });
  assert.equal(outcome.status, 'healthy');
  assert.equal(outcome.segments[0].attempts, 2);
  assert.equal(requests[0].body.input, requests[1].body.input);
  assert.equal(Object.hasOwn(requests[0].body, 'stream'), false);
  assert.deepEqual(requests[0].body, requests[1].body);
});

test('legacy omitted-stream failure is detected even when explicit false works', async () => {
  const { fetchImpl: healthyFetch } = fakeCnFetch();
  const contracts = [];
  const fetchImpl = async (url, init) => {
    const body = JSON.parse(init.body);
    contracts.push(Object.hasOwn(body, 'stream') ? String(body.stream) : 'omitted');
    if (!Object.hasOwn(body, 'stream')) return new Response('{}', { status: 502 });
    return healthyFetch(url, init);
  };
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, maxAttemptsPerSegment: 2, retryDelayMs: 0,
  });
  assert.equal(outcome.status, 'supply_failed');
  assert.equal(outcome.failureCode, 'http_502');
  assert.equal(outcome.failedRequestContract, 'stream_omitted');
  assert.deepEqual(contracts, ['omitted', 'omitted']);
});

test('local segment limit does not attribute a failure to a successful request contract', async () => {
  const { fetchImpl, requests } = fakeCnFetch({
    mutate: (base) => ({ ...base, partition: { processed: base.input.slice(0, 1), unprocessed: base.input.slice(1) } }),
  });
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, maxAttemptsPerSegment: 1, retryDelayMs: 0,
  });
  assert.equal(outcome.failureCode, 'too_many_segments');
  assert.equal(outcome.segmentCount, 6);
  assert.equal(requests.length, 6);
  assert.equal(outcome.failedRequestContract, null);
});

test('a stalled request is aborted by the segment deadline', async () => {
  const fetchImpl = async (_url, init) => await new Promise((_resolve, reject) => {
    init.signal.addEventListener('abort', () => reject(new DOMException('timed out', 'AbortError')), { once: true });
  });
  const outcome = await runContinuityProbe({
    region: 'cn', fetchImpl, decodeAudio, segmentTimeoutMs: 10,
    runTimeoutMs: 100, maxAttemptsPerSegment: 1, retryDelayMs: 0,
  });
  assert.equal(outcome.status, 'supply_failed');
  assert.equal(outcome.failureCode, 'request_timeout');
});

test('endpoint pin rejects cross-region and wrong-path probes before fetch', async () => {
  let calls = 0;
  const fetchImpl = async () => { calls += 1; throw new Error('must not run'); };
  await assert.rejects(
    runContinuityProbe({
      region: 'cn', endpoint: 'https://api.castreader.ai/api/captioned_speech_partly', fetchImpl,
    }),
    (error) => error instanceof ProbeContractError && error.code === 'cross_region_endpoint_rejected'
  );
  assert.throws(
    () => assertRegionalEndpoint('cn', 'https://api.castreader.cn/api/tts'),
    (error) => error instanceof ProbeContractError && error.code === 'invalid_endpoint_path'
  );
  assert.throws(
    () => assertRegionalEndpoint('cn', 'https://probe:secret@api.castreader.cn/api/captioned_speech_partly'),
    (error) => error instanceof ProbeContractError && error.code === 'endpoint_credentials_rejected'
  );
  assert.throws(
    () => assertRegionalEndpoint('cn', 'https://api.castreader.cn:8443/api/captioned_speech_partly'),
    (error) => error instanceof ProbeContractError && error.code === 'cross_region_endpoint_rejected'
  );
  assert.equal(calls, 0);
});

test('fixed US passage is long enough to force the partly compatibility path', () => {
  const target = targetForRegion('us');
  assert.ok((target.input.match(/\S+/gu) || []).length > 74);
  assert.equal(target.voice, 'af_heart');
  assert.equal(target.upstreamRegion, 'global');
});

test('ffmpeg progress requires a completed positive audio decode', () => {
  assert.equal(decodedDurationFromFfmpegProgress('out_time_us=210045\nprogress=end\n'), 0.210045);
  assert.equal(decodedDurationFromFfmpegProgress('out_time_us=0\nprogress=end\n'), null);
  assert.equal(decodedDurationFromFfmpegProgress('out_time_us=210045\nprogress=continue\n'), null);
});
