import { randomUUID } from 'node:crypto';
import { mkdir, open, readFile, readdir, rename, stat, unlink, writeFile } from 'node:fs/promises';
import { basename, dirname, join } from 'node:path';

async function atomicJson(path, value) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const temporary = `${path}.${process.pid}.${randomUUID()}.tmp`;
  await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
  await rename(temporary, path);
}

function processAlive(pid) {
  if (!Number.isInteger(pid) || pid < 2) return false;
  try { process.kill(pid, 0); return true; }
  catch (error) { return error?.code === 'EPERM'; }
}

export async function acquireSingleFlight(stateDir, { nowMs = Date.now(), staleAfterMs = 180_000 } = {}) {
  await mkdir(stateDir, { recursive: true, mode: 0o700 });
  const path = join(stateDir, 'probe.lock');
  const token = randomUUID();
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const handle = await open(path, 'wx', 0o600);
      await handle.writeFile(`${JSON.stringify({ pid: process.pid, token, startedAtMs: nowMs })}\n`);
      await handle.close();
      return async () => {
        try {
          const current = JSON.parse(await readFile(path, 'utf8'));
          if (current.token === token) await unlink(path);
        } catch { /* already released or replaced */ }
      };
    } catch (error) {
      if (error?.code !== 'EEXIST') throw error;
      let owner = null;
      try { owner = JSON.parse(await readFile(path, 'utf8')); } catch { /* corrupt lock can age out */ }
      const fresh = Number.isFinite(owner?.startedAtMs) && nowMs - owner.startedAtMs <= staleAfterMs;
      if (fresh || processAlive(Number(owner?.pid))) return null;
      try { await unlink(path); } catch (unlinkError) { if (unlinkError?.code !== 'ENOENT') return null; }
    }
  }
  return null;
}

export async function readMonitorState(stateDir) {
  try { return JSON.parse(await readFile(join(stateDir, 'state.json'), 'utf8')); }
  catch { return { consecutiveSupplyFailures: 0, consecutiveAlignmentDegradations: 0, lastStatus: null, lastAlertAt: null }; }
}

export function nextMonitorState(previous, outcome) {
  return {
    schemaVersion: 1,
    updatedAt: outcome.observedAt,
    lastStatus: outcome.status,
    consecutiveSupplyFailures: outcome.supplyOk ? 0 : (previous.consecutiveSupplyFailures || 0) + 1,
    consecutiveAlignmentDegradations: outcome.supplyOk && !outcome.alignmentOk
      ? (previous.consecutiveAlignmentDegradations || 0) + 1 : 0,
    lastHealthyAt: outcome.status === 'healthy' ? outcome.observedAt : previous.lastHealthyAt || null,
    lastAlertAt: previous.lastAlertAt || null,
  };
}

export function alertEnvelope(previous, state, outcome, resultPath) {
  const recovered = previous.lastStatus && previous.lastStatus !== 'healthy' && outcome.status === 'healthy';
  const firstSupplyFailure = !outcome.supplyOk && state.consecutiveSupplyFailures === 1;
  const confirmedSupplyFailure = !outcome.supplyOk && state.consecutiveSupplyFailures === 2;
  const firstAlignmentDegradation = outcome.status === 'alignment_degraded' && state.consecutiveAlignmentDegradations === 1;
  if (!recovered && !firstSupplyFailure && !confirmedSupplyFailure && !firstAlignmentDegradation) return null;
  return {
    schemaVersion: 1,
    type: recovered ? 'recovery' : outcome.status,
    severity: outcome.supplyOk ? 'warning' : state.consecutiveSupplyFailures >= 2 ? 'critical' : 'warning',
    notificationPolicy: 'dry-run',
    observedAt: outcome.observedAt,
    region: outcome.region,
    failureCode: outcome.failureCode || null,
    consecutiveSupplyFailures: state.consecutiveSupplyFailures,
    consecutiveAlignmentDegradations: state.consecutiveAlignmentDegradations,
    resultFile: basename(resultPath),
  };
}

export async function persistOutcome(stateDir, outcome, { nowMs = Date.now(), retainDays = 7, maxResults = 2016 } = {}) {
  const resultsDir = join(stateDir, 'results');
  const alertsDir = join(stateDir, 'alerts');
  await mkdir(resultsDir, { recursive: true, mode: 0o700 });
  await mkdir(alertsDir, { recursive: true, mode: 0o700 });
  const stamp = outcome.observedAt.replace(/[:.]/gu, '-');
  const resultPath = join(resultsDir, `${stamp}-${randomUUID()}.json`);
  await atomicJson(resultPath, outcome);
  await atomicJson(join(stateDir, 'latest.json'), outcome);
  const previous = await readMonitorState(stateDir);
  const state = nextMonitorState(previous, outcome);
  const envelope = alertEnvelope(previous, state, outcome, resultPath);
  if (envelope) {
    const alertPath = join(alertsDir, `${stamp}-${randomUUID()}.json`);
    await atomicJson(alertPath, envelope);
    state.lastAlertAt = outcome.observedAt;
  }
  await atomicJson(join(stateDir, 'state.json'), state);
  await pruneResults(resultsDir, { nowMs, retainDays, maxResults });
  await pruneResults(alertsDir, { nowMs, retainDays, maxResults });
  return { resultPath, envelope, state };
}

export async function pruneResults(directory, { nowMs = Date.now(), retainDays = 7, maxResults = 2016 } = {}) {
  let entries;
  try { entries = await readdir(directory, { withFileTypes: true }); }
  catch { return; }
  const rows = [];
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith('.json')) continue;
    const path = join(directory, entry.name);
    try { rows.push({ path, mtimeMs: (await stat(path)).mtimeMs }); } catch { /* raced cleanup */ }
  }
  rows.sort((a, b) => b.mtimeMs - a.mtimeMs);
  const cutoff = nowMs - retainDays * 86_400_000;
  await Promise.all(rows.filter((row, index) => index >= maxResults || row.mtimeMs < cutoff).map((row) => unlink(row.path).catch(() => undefined)));
}
