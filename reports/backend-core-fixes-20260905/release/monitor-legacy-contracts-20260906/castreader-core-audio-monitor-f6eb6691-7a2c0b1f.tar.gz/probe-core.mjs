import { createHash, randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';

const MAX_RESPONSE_BYTES = 4 * 1024 * 1024;
const MIN_AUDIO_BYTES = 128;
const DEFAULT_SEGMENT_TIMEOUT_MS = 35_000;
const DEFAULT_RUN_TIMEOUT_MS = 120_000;
const MAX_SEGMENTS = 6;
// Cover legacy client request shapes without adding synthesis requests.
const STREAM_CONTRACTS = Object.freeze([
  Object.freeze({ name: 'stream_omitted', fields: Object.freeze({}) }),
  Object.freeze({ name: 'stream_true', fields: Object.freeze({ stream: true }) }),
  Object.freeze({ name: 'stream_false', fields: Object.freeze({ stream: false }) }),
]);

const TARGETS = Object.freeze({
  us: Object.freeze({
    endpoint: 'https://api.castreader.ai/api/captioned_speech_partly',
    upstreamRegion: 'global',
    language: 'en',
    locale: 'en-US',
    voice: 'af_heart',
    input:
      'CastReader continuity probe begins with a calm sentence about steady reading and clear speech. ' +
      'The second sentence checks that another audio segment arrives without losing the remaining words or changing their order. ' +
      'A third sentence confirms that playback can continue while the next piece is prepared and that every returned audio file is independently decodable. ' +
      'The final sentence closes the fixed diagnostic passage with ordinary vocabulary and no private user material, while also verifying that the service returns every remaining word before recording a healthy result.',
  }),
  cn: Object.freeze({
    endpoint: 'https://api.castreader.cn/api/captioned_speech_partly',
    upstreamRegion: 'cn',
    language: 'zh',
    locale: 'zh-CN',
    voice: 'zf_001',
    input: '这是固定的朗读连续性检查第一段。第二段确认余下正文会继续生成，不会中途停止。第三段确认每一段音频都能独立解码并按顺序播放。',
  }),
});

export class ProbeContractError extends Error {
  constructor(code, kind = 'supply_failure') {
    super(code);
    this.name = 'ProbeContractError';
    this.code = code;
    this.kind = kind;
  }
}

export function sha256(value) {
  return createHash('sha256').update(value).digest('hex');
}

export function targetForRegion(region) {
  const target = TARGETS[region];
  if (!target) throw new ProbeContractError('invalid_region', 'monitor_fault');
  return target;
}

export function assertRegionalEndpoint(region, rawEndpoint) {
  const endpoint = new URL(rawEndpoint);
  if (endpoint.username || endpoint.password) {
    throw new ProbeContractError('endpoint_credentials_rejected', 'monitor_fault');
  }
  if (endpoint.pathname !== '/api/captioned_speech_partly') {
    throw new ProbeContractError('invalid_endpoint_path', 'monitor_fault');
  }
  const expectedHost = region === 'cn' ? 'api.castreader.cn' : 'api.castreader.ai';
  const loopback = endpoint.hostname === '127.0.0.1' || endpoint.hostname === 'localhost' || endpoint.hostname === '::1';
  if (!loopback && (endpoint.protocol !== 'https:' || endpoint.hostname !== expectedHost || endpoint.port)) {
    throw new ProbeContractError('cross_region_endpoint_rejected', 'monitor_fault');
  }
  if (loopback && !['http:', 'https:'].includes(endpoint.protocol)) {
    throw new ProbeContractError('invalid_loopback_endpoint', 'monitor_fault');
  }
  endpoint.hash = '';
  endpoint.search = '';
  return endpoint.toString();
}

function validTimestamps(value) {
  if (!Array.isArray(value) || value.length === 0) return false;
  let priorStart = -1;
  let priorEnd = -1;
  return value.every((raw) => {
    if (!raw || typeof raw !== 'object') return false;
    const start = raw.start ?? raw.start_time;
    const end = raw.end ?? raw.end_time;
    const word = raw.word;
    const valid = typeof word === 'string' && word.trim().length > 0
      && Number.isFinite(start) && Number.isFinite(end)
      && start >= 0 && end >= start && start >= priorStart && end >= priorEnd;
    if (valid) { priorStart = start; priorEnd = end; }
    return valid;
  });
}

function audioBytes(value) {
  if (typeof value !== 'string' || value.length < 128 || value.length % 4 === 1 || !/^[A-Za-z0-9+/]+={0,2}$/u.test(value)) {
    throw new ProbeContractError('invalid_audio_base64');
  }
  const bytes = Buffer.from(value, 'base64');
  if (bytes.length < MIN_AUDIO_BYTES) throw new ProbeContractError('audio_too_small');
  const id3 = bytes[0] === 0x49 && bytes[1] === 0x44 && bytes[2] === 0x33;
  const frame = bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0;
  if (!id3 && !frame) throw new ProbeContractError('invalid_mp3_header');
  return bytes;
}

async function readJsonWithinLimit(response, maximumBytes = MAX_RESPONSE_BYTES) {
  const rawLength = response.headers.get('content-length');
  if (rawLength && /^\d+$/u.test(rawLength) && Number(rawLength) > maximumBytes) {
    throw new ProbeContractError('response_too_large');
  }
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.byteLength > maximumBytes) throw new ProbeContractError('response_too_large');
  let parsed;
  try { parsed = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); }
  catch { throw new ProbeContractError('invalid_json_response'); }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new ProbeContractError('invalid_json_response');
  return parsed;
}

function combinedSignal(signals) {
  const active = signals.filter(Boolean);
  if (active.length === 1) return active[0];
  return AbortSignal.any(active);
}

export function decodedDurationFromFfmpegProgress(output) {
  if (typeof output !== 'string' || !/^progress=end$/mu.test(output)) return null;
  const times = [...output.matchAll(/^out_time_us=(\d+)$/gmu)]
    .map((match) => Number(match[1]))
    .filter((value) => Number.isFinite(value) && value > 0);
  if (times.length === 0) return null;
  return Math.max(...times) / 1_000_000;
}

export async function decodeMp3WithFfmpeg(bytes, { signal, spawnImpl = spawn } = {}) {
  return await new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new ProbeContractError('decoder_timeout', 'monitor_fault'));
      return;
    }
    let output = '';
    let error = '';
    let settled = false;
    let child;
    try {
      child = spawnImpl('ffmpeg', [
        '-v', 'error', '-f', 'mp3', '-i', 'pipe:0', '-map', '0:a:0',
        '-progress', 'pipe:1', '-nostats', '-f', 'null', '-',
      ], { stdio: ['pipe', 'pipe', 'pipe'] });
    } catch {
      reject(new ProbeContractError('decoder_unavailable', 'monitor_fault'));
      return;
    }
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      signal?.removeEventListener('abort', onAbort);
      fn(value);
    };
    const onAbort = () => {
      try { child.kill('SIGTERM'); } catch { /* best effort */ }
      finish(reject, new ProbeContractError('decoder_timeout', 'monitor_fault'));
    };
    const onOutputLimit = () => {
      try { child.kill('SIGTERM'); } catch { /* best effort */ }
      finish(reject, new ProbeContractError('decoder_output_too_large', 'monitor_fault'));
    };
    signal?.addEventListener('abort', onAbort, { once: true });
    child.on('error', () => finish(reject, new ProbeContractError('decoder_unavailable', 'monitor_fault')));
    child.stdout.on('data', (chunk) => { output += chunk; if (output.length > 32_768) onOutputLimit(); });
    child.stderr.on('data', (chunk) => { error += chunk; if (error.length > 32_768) onOutputLimit(); });
    child.on('close', (code) => {
      if (settled) return;
      if (code !== 0) return finish(reject, new ProbeContractError('audio_decode_failed'));
      const durationSeconds = decodedDurationFromFfmpegProgress(output);
      if (!durationSeconds) return finish(reject, new ProbeContractError('audio_decode_failed'));
      finish(resolve, { durationSeconds });
    });
    child.stdin.on('error', () => {});
    child.stdin.end(bytes);
  });
}

async function oneAttempt({ endpoint, region, target, input, fetchImpl, decodeAudio, signal, requestId, requestContract }) {
  let response;
  try {
    response = await fetchImpl(endpoint, {
      method: 'POST',
      headers: {
        accept: 'application/json',
        'content-type': 'application/json',
        'x-castreader-monitor': 'core-audio-continuity-v1',
        'x-request-id': requestId,
      },
      body: JSON.stringify({
        model: 'kokoro', input, voice: target.voice, voice_code: target.voice,
        language: target.language, response_format: 'mp3', return_timestamps: true,
        speed: 1, ...requestContract.fields,
      }),
      cache: 'no-store', redirect: 'error', signal,
    });
  } catch (error) {
    if (signal.aborted) throw new ProbeContractError('request_timeout');
    throw new ProbeContractError('network_failure');
  }
  if (!response.ok) throw new ProbeContractError(`http_${response.status}`);
  if (!response.headers.get('content-type')?.toLowerCase().includes('application/json')) {
    throw new ProbeContractError('invalid_content_type');
  }
  const expectedUpstreamRegion = target.upstreamRegion;
  const actualUpstreamRegion = response.headers.get('x-castreader-upstream-region');
  if (actualUpstreamRegion !== expectedUpstreamRegion) throw new ProbeContractError('region_contract_mismatch');
  const payload = await readJsonWithinLimit(response);
  if (payload.voice_code !== target.voice) throw new ProbeContractError('voice_contract_mismatch');
  const bytes = audioBytes(payload.audio);
  const decoded = await decodeAudio(bytes, { signal });
  const hasPartition = typeof payload.processed_text === 'string' || typeof payload.unprocessed_text === 'string';
  let processed;
  let unprocessed;
  if (hasPartition) {
    if (typeof payload.processed_text !== 'string' || typeof payload.unprocessed_text !== 'string') {
      throw new ProbeContractError('partial_partition_missing');
    }
    processed = payload.processed_text;
    unprocessed = payload.unprocessed_text;
  } else {
    processed = input;
    unprocessed = '';
  }
  if (!processed || processed + unprocessed !== input || (unprocessed && unprocessed.length >= input.length)) {
    throw new ProbeContractError('remainder_did_not_advance');
  }
  return {
    processed, unprocessed, audioBytes: bytes.byteLength,
    durationSeconds: decoded.durationSeconds,
    timestampsOk: validTimestamps(payload.timestamps),
    timestampCount: Array.isArray(payload.timestamps) ? payload.timestamps.length : 0,
    gateway: response.headers.get('x-castreader-gateway') || null,
    upstreamNode: response.headers.get('x-castreader-upstream-node') || null,
    upstreamSource: response.headers.get('x-castreader-upstream-source') || null,
    upstreamRevision: response.headers.get('x-castreader-upstream-revision') || null,
    region,
  };
}

async function attemptSegment(options, maxAttempts, retryDelayMs) {
  let lastError;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const timeoutSignal = AbortSignal.timeout(options.segmentTimeoutMs);
    try {
      return { value: await oneAttempt({ ...options, signal: combinedSignal([options.runSignal, timeoutSignal]) }), attempts: attempt };
    } catch (error) {
      lastError = error;
      if (options.runSignal?.aborted || attempt === maxAttempts) break;
      await new Promise((resolve) => setTimeout(resolve, retryDelayMs));
    }
  }
  throw lastError;
}

export async function runContinuityProbe({
  region,
  endpoint,
  fetchImpl = globalThis.fetch,
  decodeAudio = decodeMp3WithFfmpeg,
  segmentTimeoutMs = DEFAULT_SEGMENT_TIMEOUT_MS,
  runTimeoutMs = DEFAULT_RUN_TIMEOUT_MS,
  maxAttemptsPerSegment = 2,
  retryDelayMs = 1_000,
  now = () => new Date(),
  makeRequestId = () => randomUUID(),
} = {}) {
  const target = targetForRegion(region);
  const fixedEndpoint = assertRegionalEndpoint(region, endpoint || target.endpoint);
  const runController = new AbortController();
  const timer = setTimeout(() => runController.abort(), runTimeoutMs);
  timer.unref?.();
  const started = Date.now();
  const segments = [];
  let remaining = target.input;
  let failedRequestContract = null;
  try {
    while (remaining) {
      if (segments.length >= MAX_SEGMENTS) throw new ProbeContractError('too_many_segments');
      const requestContract = STREAM_CONTRACTS[segments.length % STREAM_CONTRACTS.length];
      let result;
      try {
        result = await attemptSegment({
          endpoint: fixedEndpoint, region, target, input: remaining, fetchImpl, decodeAudio,
          runSignal: runController.signal, segmentTimeoutMs,
          requestId: `core-audio-${region}-${makeRequestId()}`,
          requestContract,
        }, maxAttemptsPerSegment, retryDelayMs);
      } catch (error) {
        failedRequestContract = requestContract.name;
        throw error;
      }
      const part = result.value;
      segments.push({
        index: segments.length, attempts: result.attempts,
        requestContract: requestContract.name,
        processedCharacters: part.processed.length, remainingCharacters: part.unprocessed.length,
        audioBytes: part.audioBytes, durationSeconds: part.durationSeconds,
        timestampsOk: part.timestampsOk, timestampCount: part.timestampCount,
        gateway: part.gateway, upstreamNode: part.upstreamNode,
        upstreamSource: part.upstreamSource, upstreamRevision: part.upstreamRevision,
      });
      remaining = part.unprocessed;
    }
    if (segments.length < 2) throw new ProbeContractError('single_segment_contract');
    const alignmentOk = segments.every((segment) => segment.timestampsOk);
    return {
      schemaVersion: 1,
      probe: 'core-audio-continuity',
      observedAt: now().toISOString(),
      region,
      endpoint: new URL(fixedEndpoint).origin + new URL(fixedEndpoint).pathname,
      inputSha256: sha256(target.input),
      inputCharacters: target.input.length,
      language: target.language,
      locale: target.locale,
      voice: target.voice,
      supplyOk: true,
      alignmentOk,
      status: alignmentOk ? 'healthy' : 'alignment_degraded',
      elapsedMs: Date.now() - started,
      segmentCount: segments.length,
      totalAudioBytes: segments.reduce((sum, segment) => sum + segment.audioBytes, 0),
      totalDurationSeconds: segments.reduce((sum, segment) => sum + segment.durationSeconds, 0),
      segments,
    };
  } catch (error) {
    const known = error instanceof ProbeContractError ? error : new ProbeContractError('unexpected_monitor_error', 'monitor_fault');
    return {
      schemaVersion: 1,
      probe: 'core-audio-continuity',
      observedAt: now().toISOString(),
      region,
      endpoint: new URL(fixedEndpoint).origin + new URL(fixedEndpoint).pathname,
      inputSha256: sha256(target.input),
      inputCharacters: target.input.length,
      language: target.language,
      locale: target.locale,
      voice: target.voice,
      supplyOk: false,
      alignmentOk: false,
      status: known.kind === 'monitor_fault' ? 'monitor_error' : 'supply_failed',
      failureCode: known.code,
      failedRequestContract,
      elapsedMs: Date.now() - started,
      segmentCount: segments.length,
      totalAudioBytes: segments.reduce((sum, segment) => sum + segment.audioBytes, 0),
      totalDurationSeconds: segments.reduce((sum, segment) => sum + segment.durationSeconds, 0),
      segments,
    };
  } finally {
    clearTimeout(timer);
  }
}
