#!/usr/bin/env node
import { realpathSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import { runContinuityProbe, targetForRegion } from './probe-core.mjs';
import { acquireSingleFlight, persistOutcome } from './state-store.mjs';

function parseArgs(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index += 1) {
    const key = argv[index];
    if (!key.startsWith('--')) throw new Error('invalid_argument');
    args[key.slice(2)] = argv[++index];
  }
  return args;
}

export async function main(argv = process.argv.slice(2), env = process.env) {
  const args = parseArgs(argv);
  const region = String(args.region || env.CORE_AUDIO_MONITOR_REGION || '').toLowerCase();
  targetForRegion(region);
  const stateDir = resolve(args['state-dir'] || env.CORE_AUDIO_MONITOR_STATE_DIR || `/var/lib/castreader-core-audio-monitor/${region}`);
  const release = await acquireSingleFlight(stateDir, { staleAfterMs: 180_000 });
  if (!release) {
    process.stdout.write(`${JSON.stringify({ ok: true, status: 'skipped_single_flight', region })}\n`);
    return 0;
  }
  try {
    const outcome = await runContinuityProbe({ region, endpoint: args.endpoint || env.CORE_AUDIO_MONITOR_ENDPOINT });
    const persisted = await persistOutcome(stateDir, outcome, {
      retainDays: Number(env.CORE_AUDIO_MONITOR_RETAIN_DAYS || 7),
      maxResults: Number(env.CORE_AUDIO_MONITOR_MAX_RESULTS || 2016),
    });
    process.stdout.write(`${JSON.stringify({
      ok: outcome.supplyOk,
      status: outcome.status,
      region: outcome.region,
      observedAt: outcome.observedAt,
      segmentCount: outcome.segmentCount,
      elapsedMs: outcome.elapsedMs,
      failureCode: outcome.failureCode || null,
      alert: persisted.envelope ? 'dry-run-recorded' : 'none',
    })}\n`);
    return outcome.supplyOk ? 0 : 2;
  } finally {
    await release();
  }
}

export function isDirectExecution(moduleUrl = import.meta.url, argvPath = process.argv[1]) {
  if (!argvPath) return false;
  try {
    // Production executes /opt/.../current/run.mjs through an immutable-release
    // symlink. Node resolves import.meta.url to the real file while argv keeps
    // the symlink path, so a lexical URL comparison would silently skip main().
    return realpathSync(fileURLToPath(moduleUrl)) === realpathSync(argvPath);
  } catch {
    return moduleUrl === pathToFileURL(resolve(argvPath)).href;
  }
}

if (isDirectExecution()) {
  main().then((code) => { process.exitCode = code; }).catch((error) => {
    process.stderr.write(`${JSON.stringify({ ok: false, status: 'monitor_error', failureCode: error?.message || 'unexpected_monitor_error' })}\n`);
    process.exitCode = 2;
  });
}
