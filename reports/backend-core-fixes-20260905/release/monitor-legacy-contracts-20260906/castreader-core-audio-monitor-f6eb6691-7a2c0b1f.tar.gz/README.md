# Core audio continuity monitor

This is an independent, local-state monitor for the US and CN TTS routes. Every run sends one fixed, non-user diagnostic passage through `captioned_speech_partly`, follows `unprocessed_text` until empty, and requires at least two independently decodable MP3 segments. It verifies exact remainder progress and the response's pinned upstream region. Redirects are disabled.

Successive segments omit `stream`, send `stream: true`, and send `stream: false`, repeating that order if needed. Retries preserve the same request contract. This covers the legacy omitted-stream failure without extra synthesis requests; each receipt records the contract actually exercised. A two-segment result covers only omitted and true, so it does not claim all three variants were verified in that run.

Timestamp validity is recorded separately. Missing or malformed timestamps produce `alignment_degraded` while `supplyOk` remains true, because playable continuous audio is the primary contract. HTTP, region, partition, audio or decoder failures produce `supply_failed` or `monitor_error` and exit 2.

The fixed voices are preset voices (`af_heart` for US, `zf_001` for CN); the monitor never reads or chooses a user clone voice. Result files contain only diagnostic hashes, counts, timings and whitelisted route metadata. Audio bytes and diagnostic prose are not persisted.

Runtime prerequisites are Node.js 22 or newer, `ffmpeg` from the regional operating-system package repository, DNS and outbound HTTPS to that region's public API. `ffmpeg` fully decodes each MP3 to a null output and reports decoded duration; it receives audio through stdin, and the probe never writes audio to disk.

Run manually only in an authorized probe window:

```bash
node /opt/castreader-core-audio-monitor/current/run.mjs --region cn \
  --state-dir /var/lib/castreader-core-audio-monitor/cn
```

The endpoint is pinned to `api.castreader.cn` for CN and `api.castreader.ai` for US. Public overrides cannot use credentials, a custom port or a different path. A loopback endpoint is permitted for a same-host ingress. Any other hostname or path is rejected before a request is sent, and every successful response must identify the expected upstream service region.

`systemd/` contains an instance service and timer. The service has a 150-second bound; the script also has a 120-second total deadline, 35-second segment deadlines and an atomic local single-flight lock. JSON results and dry-run alert envelopes remain under `/var/lib/castreader-core-audio-monitor/<region>` for seven days, capped at 2016 files per directory. It never restarts TTS, QuickRead, clone, Nari, tunnels, Nginx or the host. There is deliberately no webhook sender; a separate reviewed notifier may consume the dry-run envelope later.

Install as a separate immutable artifact under `/opt/castreader-core-audio-monitor/releases/<sha>` and atomically update `/opt/castreader-core-audio-monitor/current`. Enable only the regional timer that belongs on that host, for example `castreader-core-audio-monitor@cn.timer` on the CN controller. Installation and enablement are production changes and are not performed by this commit.

Tests are network-free and do not synthesize audio:

```bash
node --test scripts/core-audio-monitor/*.test.mjs
```
