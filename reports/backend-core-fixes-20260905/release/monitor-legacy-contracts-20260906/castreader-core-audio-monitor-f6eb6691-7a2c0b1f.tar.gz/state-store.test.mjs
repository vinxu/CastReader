import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtemp, readFile, readdir, rm, symlink, utimes, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

import {
  acquireSingleFlight,
  persistOutcome,
  pruneResults,
  readMonitorState,
} from './state-store.mjs';
import { main } from './run.mjs';

async function temporaryDirectory(t) {
  const path = await mkdtemp(join(tmpdir(), 'core-audio-monitor-test-'));
  t.after(() => rm(path, { recursive: true, force: true }));
  return path;
}

function outcome(overrides = {}) {
  return {
    schemaVersion: 1,
    probe: 'core-audio-continuity',
    observedAt: '2026-09-05T12:00:00.000Z',
    region: 'cn',
    supplyOk: true,
    alignmentOk: true,
    status: 'healthy',
    segmentCount: 3,
    ...overrides,
  };
}

test('local lock provides single flight and releases only its own token', async (t) => {
  const directory = await temporaryDirectory(t);
  const release = await acquireSingleFlight(directory, { nowMs: 10_000 });
  assert.equal(typeof release, 'function');
  assert.equal(await acquireSingleFlight(directory, { nowMs: 10_001 }), null);
  await release();
  const releaseAgain = await acquireSingleFlight(directory, { nowMs: 10_002 });
  assert.equal(typeof releaseAgain, 'function');
  await releaseAgain();
});

test('a stale lock whose owner is gone is removed safely', async (t) => {
  const directory = await temporaryDirectory(t);
  await writeFile(join(directory, 'probe.lock'), JSON.stringify({ pid: 0, token: 'stale', startedAtMs: 1 }));
  const release = await acquireSingleFlight(directory, { nowMs: 300_000, staleAfterMs: 1_000 });
  assert.equal(typeof release, 'function');
  await release();
});

test('supply failures alert once as warning, confirm as critical, then recover', async (t) => {
  const directory = await temporaryDirectory(t);
  const first = await persistOutcome(directory, outcome({
    observedAt: '2026-09-05T12:01:00.000Z', supplyOk: false, alignmentOk: false,
    status: 'supply_failed', failureCode: 'http_502',
  }));
  assert.equal(first.envelope.severity, 'warning');
  assert.equal(first.envelope.notificationPolicy, 'dry-run');
  assert.equal(first.state.consecutiveSupplyFailures, 1);

  const second = await persistOutcome(directory, outcome({
    observedAt: '2026-09-05T12:02:00.000Z', supplyOk: false, alignmentOk: false,
    status: 'supply_failed', failureCode: 'http_502',
  }));
  assert.equal(second.envelope.severity, 'critical');
  assert.equal(second.state.consecutiveSupplyFailures, 2);

  const third = await persistOutcome(directory, outcome({
    observedAt: '2026-09-05T12:03:00.000Z',
  }));
  assert.equal(third.envelope.type, 'recovery');
  assert.equal(third.envelope.notificationPolicy, 'dry-run');
  assert.equal(third.state.consecutiveSupplyFailures, 0);
});

test('alignment degradation is recorded separately from supply failure', async (t) => {
  const directory = await temporaryDirectory(t);
  const persisted = await persistOutcome(directory, outcome({
    status: 'alignment_degraded', alignmentOk: false,
  }));
  assert.equal(persisted.envelope.severity, 'warning');
  assert.equal(persisted.state.consecutiveSupplyFailures, 0);
  assert.equal(persisted.state.consecutiveAlignmentDegradations, 1);
  assert.equal((await readMonitorState(directory)).lastStatus, 'alignment_degraded');
});

test('retention removes expired and over-cap result files', async (t) => {
  const directory = await temporaryDirectory(t);
  const nowMs = Date.parse('2026-09-05T12:00:00.000Z');
  const paths = [];
  for (let index = 0; index < 4; index += 1) {
    const path = join(directory, `${index}.json`);
    await writeFile(path, '{}');
    const ageDays = index === 0 ? 9 : 0;
    const timestamp = new Date(nowMs - ageDays * 86_400_000 - index * 1_000);
    await utimes(path, timestamp, timestamp);
    paths.push(path);
  }
  await pruneResults(directory, { nowMs, retainDays: 7, maxResults: 2 });
  const names = (await readdir(directory)).sort();
  assert.deepEqual(names, ['1.json', '2.json']);
  assert.equal(paths.length, 4);
});

test('systemd contract bounds runs, separates regional state and cannot restart production', async () => {
  const base = new URL('./systemd/', import.meta.url);
  const service = await readFile(new URL('castreader-core-audio-monitor@.service', base), 'utf8');
  const timer = await readFile(new URL('castreader-core-audio-monitor@.timer', base), 'utf8');
  assert.match(service, /^TimeoutStartSec=150$/mu);
  assert.match(service, /^StateDirectory=castreader-core-audio-monitor\/%i$/mu);
  assert.match(service, /^DynamicUser=yes$/mu);
  assert.doesNotMatch(service, /^Restart=/mu);
  assert.doesNotMatch(service, /systemctl|supervisorctl|pm2|docker|kill/u);
  assert.match(timer, /^OnUnitActiveSec=5min$/mu);
  assert.match(timer, /^Persistent=true$/mu);
});

test('invalid region is rejected before a lock or state file is created', async (t) => {
  const directory = await temporaryDirectory(t);
  await assert.rejects(main(['--region', 'invalid', '--state-dir', directory], {}), /invalid_region/u);
  assert.deepEqual(await readdir(directory), []);
});

test('the production current symlink still executes the monitor CLI', async (t) => {
  const directory = await temporaryDirectory(t);
  const linkedEntry = join(directory, 'run.mjs');
  await symlink(fileURLToPath(new URL('./run.mjs', import.meta.url)), linkedEntry);
  const stateDirectory = join(directory, 'state');
  const result = spawnSync(process.execPath, [
    linkedEntry, '--region', 'invalid', '--state-dir', stateDirectory,
  ], { encoding: 'utf8' });
  assert.equal(result.status, 2);
  assert.match(result.stderr, /"failureCode":"invalid_region"/u);
  await assert.rejects(readFile(join(stateDirectory, 'state.json')), /ENOENT/u);
});
